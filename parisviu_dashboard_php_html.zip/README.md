# Dashboard Paris Viu - PHP + HTML

## Como usar

1. Envie o arquivo `index.php` para sua hospedagem com PHP habilitado.
2. Acesse pelo navegador, por exemplo:
   `https://seudominio.com/index.php`

## Estrutura

- Os dados das campanhas e criativos ficam no início do arquivo PHP, no array `$campaigns`.
- O restante do arquivo renderiza o HTML automaticamente.
- Não há dependência de banco de dados, JavaScript ou arquivos externos.

## Observação

Esta versão mantém a navegação interna por hiperlinks, otimização para celular e dashboards individuais por anúncio.
